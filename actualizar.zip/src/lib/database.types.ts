// Archivo de tipos mock para tests y compatibilidad
export type Database = any;
