declare module 'react-link-preview';
